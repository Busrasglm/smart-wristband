# Sağlık bilgilerini saklamak için bir veritabanı oluşturuyoruz
health_database = {}

# Kullanıcıdan temel sağlık bilgilerini alıyoruz
ad = input("Adınız: ")
soyad = input("Soyadınız: ")
yas = int(input("Yaşınız: "))
kimlik_no = int(input("Kimlik Numaranız: "))
hastalik = input("Hastalık giriniz (virgülle ayırınız): ").split(',')

# Sağlık bilgilerini bir sözlükte saklıyoruz
health_info = {
    "Ad": ad,
    "Soyad": soyad,
    "Yaş": yas,
    "Kimlik No": kimlik_no,
    "Hastalık": hastalik
}

# Nabız bilgilerini alıyoruz
nabiz = int(input("Nabzınızı girin: "))

# Nabız değerine göre sağlık durumunu değerlendiriyoruz
if nabiz < 80:
    saglik_durumu = "Ağır"
elif 80 <= nabiz < 100:
    saglik_durumu = "Orta"
else:
    saglik_durumu = "İyi"

# Sağlık durumunu sağlık bilgilerine ekliyoruz
health_info["Sağlık Durumu"] = saglik_durumu

# Sağlık bilgilerini veritabanına ekliyoruz
health_database[kimlik_no] = health_info

# Kullanıcının sağlık bilgilerini görüntülüyoruz
print("\nSağlık Bilgileriniz:")
for key, value in health_info.items():
    print(key + ": " + str(value))


from flask import Flask, render_template, request

app = Flask(__name__)

# Sağlık bilgilerini saklamak için bir veritabanı oluşturuyoruz
health_database = {}

@app.route('/', methods=['GET', 'POST'])
def index():
    if request.method == 'POST':
        ad = request.form['ad']
        soyad = request.form['soyad']
        yas = int(request.form['yas'])
        kimlik_no = int(request.form['kimlik_no'])
        hastalik = request.form['hastalik'].split(',')
        nabiz = int(request.form['nabiz'])

        if nabiz < 80:
            saglik_durumu = "Ağır"
        elif 80 <= nabiz < 100:
            saglik_durumu = "Orta"
        else:
            saglik_durumu = "İyi"

        health_info = {
            "Ad": ad,
            "Soyad": soyad,
            "Yaş": yas,
            "Kimlik No": kimlik_no,
            "Hastalık": hastalik,
            "Sağlık Durumu": saglik_durumu
        }

        health_database[kimlik_no] = health_info

    return render_template('index.html', health_database=health_database)

if __name__ == '__main__':
    app.run(debug=True)

